# Knowledge Graph Model
