# Memory Model
