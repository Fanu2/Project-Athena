# Retrieval Model
